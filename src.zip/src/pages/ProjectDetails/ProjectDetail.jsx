import { ArrowLeft } from 'lucide-react'
import React from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import { ProjectData } from '../../UserData/ProjectData';
import "./ProjectDetail.css"

const ProjectDetail = () => {

    const navigate = useNavigate();
    const { slug } = useParams();

    const project = ProjectData.find((data) => data.slug === slug);

    if (!project) {
        return <div>Project not found</div>
    }

    return (
        <div className='detail-section'>
            <button className='detail-btn' onClick={() => navigate("/")}><ArrowLeft size={ 16 }/>Back to Projects</button>
            <div className='detail-page'>
                <h1>{project.name}</h1>
                <h2>{project.duration}</h2>
                <p>{project.overview}</p>
                <h3>My Contribution</h3>
                <ul>
                    {project.contribution.map((item) => (
                        <li key={item}>{item}</li>
                    ))}
                </ul>
                <h3>Challenges</h3>
                <ul>
                    {project.challenges.map((item) => (
                        <li key={item}>{item}</li>
                    ))}
                </ul>
                <span>{project.stack.join(" - ")}</span>
            </div>
        </div>
    )
}

export default ProjectDetail