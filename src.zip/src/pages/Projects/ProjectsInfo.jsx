import React from 'react'
import "./ProjectInfo.css"
import { ProjectData } from '../../UserData/ProjectData'
import { ArrowUpRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

const ProjectsInfo = () => {

  const navigate = useNavigate();

  return (
    <div id="projects" className='project-section'>
      <h1>Project Work</h1>
      <div className='project-container'>
        {ProjectData.map((data) => {
          const Icon = data.icon;
          return (
            <div className='project-card' key={data.id}>
              <div className="project-icon">
                <Icon size={22} />
              </div>
              <h2>{data.name}</h2>
              <p>{data.description}</p>
              <span>{data.tech}</span>
              <button className="learn-more-btn" onClick={() => navigate(`/projects/${data.slug}`)}>Learn More<ArrowUpRight size={15} /></button>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default ProjectsInfo