import React, { useEffect, useState } from "react";
import "./Home.css";

const Home = () => {
    const [nameText, setNameText] = useState("");
    const [roleText, setRoleText] = useState("");
    const [typingName, setTypingName] = useState(true);
    const [typingRole, setTypingRole] = useState(false);

    const name = "Stuti Bhangale";
    const role = "Frontend Developer";

    useEffect(() => {
        let nameIndex = 0;
        let roleIndex = 0;
        let roleTimeout;
        let roleInterval;

        const nameInterval = setInterval(() => {
            setNameText(name.slice(0, nameIndex + 1));
            nameIndex++;

            if (nameIndex === name.length) {
                clearInterval(nameInterval);
                setTypingName(false);

                roleTimeout = setTimeout(() => {
                    setTypingRole(true);

                    roleInterval = setInterval(() => {
                        setRoleText(role.slice(0, roleIndex + 1));
                        roleIndex++;

                        if (roleIndex === role.length) {
                            clearInterval(roleInterval);
                            setTypingRole(false);
                        }
                    }, 100);
                }, 300);
            }
        }, 100);

        return () => {
            clearInterval(nameInterval);
            clearInterval(roleInterval);
            clearTimeout(roleTimeout);
        };
    }, []);

    return (
        <main id="home" className="home">
            <div className="home-content">

                <div className="home-info">
                    <p>Hi, I'm</p>

                    <h2>
                        {nameText}
                        {typingName && <span className="typing-cursor">|</span>}
                    </h2>

                    <h2>
                        {roleText}
                        {typingRole && <span className="typing-cursor">|</span>}
                    </h2>
                </div>

                <div className="home-description">
                    <p>
                        I build interfaces that make complex products simple.
                    </p>

                    <p>
                        I have 3+ years of experience building enterprise applications
                        across payments and AI. I work with React, AngularJS, TypeScript,
                        JavaScript, Redux and REST APIs, turning complex requirements into
                        clean, intuitive and maintainable experiences. My work includes
                        configurable workflows, dynamic forms, reusable components,
                        data-driven interfaces and AI-powered experiences.
                    </p>
                </div>

                <div className="home-summary">
                    <h2>How I Work</h2>

                    <p>
                        Understand → Design → Build → Integrate → Refine
                    </p>

                    <p>
                        I focus on understanding the problem first, translating it into
                        clear user flows, building reusable frontend components, integrating
                        APIs, and continuously refining the experience with cross-functional
                        teams.
                    </p>
                </div>

            </div>
        </main>
    );
};

export default Home;