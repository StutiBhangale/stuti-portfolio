import React from 'react';
import "./Navbar.css";

const Navbar = () => {
    return (
        <nav className="navbar">
            <h1 className="navbar-logo">Stuti Bhangale</h1>
            <div className="navbar-links">
                <a href="/#home">Home</a>
                <a href="/#projects">Projects</a>
                <a href="/#skills">Skills</a>
                <a href="/#achievement">Achievements</a>
                <a href="/#contact">Contact</a>
                <a
                    href='/Stuti_Bhangale_Resume.docx'
                    download='Stuti_Bhangale_Resume.docx'
                    className='resume-btn'
                >Resume</a>
            </div>
        </nav>
    )
}

export default Navbar;